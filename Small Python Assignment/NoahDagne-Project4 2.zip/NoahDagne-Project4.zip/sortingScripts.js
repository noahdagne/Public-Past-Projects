
   document.getElementById("oglistdiv").style.visibility= "hidden";
    document.getElementById("sortedlistdiv").style.visibility= "hidden";
   var array= [];
   
   function generatorArray() {
    
    var number = parseInt(document.getElementById("input").value);
     while(array.length<number){
        array.push(Math.floor((Math.random() *number)) +1);
     }
    if(number>4 && number<1001){
        var tostring =document.getElementById("listone");
        tostring.innerHTML = array.toString();
        
    document.getElementById("oglistdiv").style.visibility= "visible";
    document.getElementById("sortedlistdiv").style.visibility= "visible";}

    }
    
    function originalList(){
        var swaps = 0;
        var comparison = 0;
        var minIndex;
        var current;
        var lengthArray = array.length;
         
         
        for (var i = 0; i< lengthArray; i++){
            minIndex = i;
            for(var j= i+1; j<lengthArray; j++){
                if(array[j]<array[minIndex]){
                    minIndex= j;
                    comparison++;
                }
            }
            if(minIndex != i){
                swaps ++;
                current = array[i];
                array[i] = array[minIndex];
                array[minIndex] = current;
    
        }
        document.getElementById("listtwo").innerHTML = array;
        document.getElementById("metrics").innerHTML = " The number of comparisons = " + comparison + " and the number of swaps  = " + swaps;
    }
    } 
    
    
    
    function selectList(){
         var swaps = 0;
        var comparison = 0;
        var minIndex;
        var current;
        for(var i = 0; i < array.length; i++){
            minIndex = i;
            var temp = array[i];        
        
            for(j=i-1; j > -1 && array[j] > array[i]; j--){
               if(array[j]<array[minIndex]) 
                array[j+1] = array[j];
                 minIndex= j;
                 comparison++;
            }
            
        array[j+1] = temp;
          if(minIndex != i){
                swaps ++;
                current = array[i];
                array[i] = array[minIndex];
                array[minIndex] = current;
    
        }
        document.getElementById("listtwo").innerHTML = array;
        document.getElementById("metrics").innerHTML = " The number of comparisons = " + comparison + " and the number of swaps  = " + swaps;
        }
 var ans = document.getElementById("listtwo");
    ans.innerHTML= array;
    }
    
    
    
